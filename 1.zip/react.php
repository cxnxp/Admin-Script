<?php

require_once('ayarlar.php');
echo filemtime($phpYolu);

?>