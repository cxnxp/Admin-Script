<?php 

$adminSifre="ekipsifrehack31";//admin şifresi

$phpYolu="ekipozelgiris.php";//kayıt yolu




 ?>
